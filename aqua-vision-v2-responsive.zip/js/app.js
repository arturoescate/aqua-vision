
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", open);
});

mainNav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

const progress = document.getElementById("scrollProgress");
window.addEventListener("scroll", () => {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  progress.style.width = max > 0 ? `${(window.scrollY / max) * 100}%` : "0%";
});

const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const waterStream = document.getElementById("waterStream");
const startSimulation = document.getElementById("startSimulation");
const resetSimulation = document.getElementById("resetSimulation");

startSimulation.addEventListener("click", async () => {
  startSimulation.classList.add("hidden");
  resetSimulation.classList.remove("hidden");
  waterStream.classList.add("on");

  for (let i = 1; i <= 6; i++) {
    await sleep(i === 1 ? 450 : 850);
    document.getElementById(`status${i}`).classList.add("active");
    if (i === 5) waterStream.classList.remove("on");
  }
});

resetSimulation.addEventListener("click", () => {
  waterStream.classList.remove("on");
  for (let i = 1; i <= 6; i++) {
    document.getElementById(`status${i}`).classList.remove("active");
  }
  startSimulation.classList.remove("hidden");
  resetSimulation.classList.add("hidden");
});

const statObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    entry.target.querySelectorAll("[data-count]").forEach(counter => {
      const target = Number(counter.dataset.count);
      let current = 0;
      const timer = setInterval(() => {
        current++;
        counter.textContent = current;
        if (current >= target) clearInterval(timer);
      }, 220);
    });
    statObserver.unobserve(entry.target);
  });
}, { threshold: 0.35 });

const statsGrid = document.querySelector(".stats-grid");
if (statsGrid) statObserver.observe(statsGrid);

const questions = [
  {
    question: "¿Qué debes hacer si observas un grifo goteando?",
    options: [
      ["Ignorarlo porque es poca agua", false],
      ["Cerrarlo bien y avisar a un adulto", true],
      ["Jugar con el agua", false]
    ]
  },
  {
    question: "¿Cuál es la primera acción de Aqua Vision?",
    options: [
      ["La cámara detecta el posible desperdicio", true],
      ["Se apagan las luces", false],
      ["Se cierra el colegio", false]
    ]
  },
  {
    question: "¿Qué ocurre si el desperdicio continúa?",
    options: [
      ["No pasa nada", false],
      ["Se cierra el grifo y se envía una alerta máxima", true],
      ["La alarma se desconecta", false]
    ]
  },
  {
    question: "¿Qué hábito ayuda a cuidar el agua?",
    options: [
      ["Usar solo lo necesario", true],
      ["Dejar el grifo abierto", false],
      ["No reportar fugas", false]
    ]
  }
];

let questionIndex = 0;
let quizScore = 0;
let answered = false;

const quizQuestion = document.getElementById("quizQuestion");
const quizOptions = document.getElementById("quizOptions");
const quizFeedback = document.getElementById("quizFeedback");
const nextQuestion = document.getElementById("nextQuestion");
const scoreLabel = document.getElementById("quizScore");
const tankWater = document.getElementById("tankWater");

function renderQuestion() {
  answered = false;
  quizFeedback.textContent = "";
  nextQuestion.classList.add("hidden");
  quizOptions.innerHTML = "";

  const current = questions[questionIndex];
  quizQuestion.textContent = current.question;

  current.options.forEach(([text, correct]) => {
    const button = document.createElement("button");
    button.className = "quiz-option";
    button.textContent = text;
    button.addEventListener("click", () => answerQuestion(correct, button));
    quizOptions.appendChild(button);
  });
}

function answerQuestion(correct, button) {
  if (answered) return;
  answered = true;
  quizOptions.querySelectorAll("button").forEach(btn => btn.disabled = true);

  if (correct) {
    quizScore += 25;
    button.style.background = "#E6FFF6";
    button.style.borderColor = "#20A779";
    quizFeedback.textContent = "¡Correcto! Protegiste el agua. 💧";
    quizFeedback.style.color = "#168F69";
  } else {
    button.style.background = "#FFF0F1";
    button.style.borderColor = "#E8505B";
    quizFeedback.textContent = "Casi. La respuesta correcta protege el agua.";
    quizFeedback.style.color = "#C33A45";
    tankWater.style.height = `${Math.max(25, 70 - (questionIndex + 1) * 10)}%`;
  }

  scoreLabel.textContent = `Puntaje: ${quizScore}`;
  nextQuestion.classList.remove("hidden");
}

nextQuestion.addEventListener("click", () => {
  questionIndex++;
  if (questionIndex >= questions.length) {
    quizQuestion.textContent = "¡Reto completado!";
    quizOptions.innerHTML = "";
    quizFeedback.textContent = quizScore >= 75
      ? "¡Excelente! Eres un verdadero protector del agua. 🌊"
      : "Buen intento. Cada acción responsable cuenta. 💙";
    nextQuestion.classList.add("hidden");
    return;
  }
  renderQuestion();
});

renderQuestion();

const symbols = ["📷","🚨","✉️","🚰","💧","🔌"];
const deck = [...symbols, ...symbols].sort(() => Math.random() - 0.5);
const memoryGrid = document.getElementById("memoryGrid");
const memoryMessage = document.getElementById("memoryMessage");
let firstCard = null;
let locked = false;
let matched = 0;

deck.forEach(symbol => {
  const card = document.createElement("button");
  card.className = "memory-card";
  card.textContent = "?";
  card.dataset.symbol = symbol;
  card.addEventListener("click", () => flipCard(card));
  memoryGrid.appendChild(card);
});

function flipCard(card) {
  if (locked || card.classList.contains("matched") || card === firstCard) return;

  card.textContent = card.dataset.symbol;
  card.classList.add("revealed");

  if (!firstCard) {
    firstCard = card;
    return;
  }

  if (firstCard.dataset.symbol === card.dataset.symbol) {
    firstCard.classList.add("matched");
    card.classList.add("matched");
    firstCard = null;
    matched += 2;

    if (matched === deck.length) {
      memoryMessage.textContent = "¡Encontraste todos los pares! 🎉";
    }
  } else {
    locked = true;
    setTimeout(() => {
      firstCard.textContent = "?";
      card.textContent = "?";
      firstCard.classList.remove("revealed");
      card.classList.remove("revealed");
      firstCard = null;
      locked = false;
    }, 750);
  }
}

document.getElementById("certificateButton").addEventListener("click", () => {
  const name = prompt("Escribe tu nombre para el certificado:");
  if (!name) return;

  document.getElementById("certificateName").textContent = name.toUpperCase();
  const certificate = document.getElementById("certificate");
  certificate.classList.remove("hidden");
  certificate.scrollIntoView({ behavior: "smooth", block: "center" });
});
